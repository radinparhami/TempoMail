from setuptools import setup

setup(
    name='TempoMail',
    version='1.0.2',
    description='python temp-mail liberary',
    author='Radin',
    download_url="https://github.com/radinparhami/TempoMail/releases/latest",
    url="https://github.com/radinparhami",
    author_email="radinparhami107@gmail.com",
    install_requires=['requests'],
)
