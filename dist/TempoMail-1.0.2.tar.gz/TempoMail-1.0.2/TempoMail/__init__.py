from TempoMail import types, core, client

__version__ = '1.0'
